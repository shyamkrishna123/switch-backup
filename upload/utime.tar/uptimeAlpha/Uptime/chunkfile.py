import pickle
class chunkfile():
	"""docstring for chunkfile"""
	def __init__(self,datum):
		self.chunks = []
		self.hosts = datum
		
# Load t
	def chunkIt(self, num):
		avg = len(self.hosts) / float(num)
		out = []
		last = 0.0
		while last < len(self.hosts):
			out.append(self.hosts[int(last):int(last + avg)])
			last += avg
		return out
	def hostQue(self):
		chunk = self.chunkIt(5)
		self.chunks = chunk
		return self.chunks
