l1=['hiklo']

f=open('f1.txt','w')
s1='\n'.join(l1)
f.write(s1)
f.close()