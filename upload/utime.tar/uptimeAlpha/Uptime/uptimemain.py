from chunkfile import chunkfile
from threading import Thread
import threading
from uptimecheck import uptimecheck
from time import sleep
data = ('\n\n', [[u'192.168.68.68', u'192.168.68.68', u'192.168.68.6', u'192.168.68.100', u'192.168.68.101'], [u'192.168.68.69', u'192.168.68.151', u'192.168.68.31', u'10.155.8.160', u'192.168.68.17'], [u'192.168.68.6', u'192.168.68.7', u'192.168.68.8', u'192.168.68.9', u'192.168.68.10', u'192.168.68.11'], [u'192.168.68.12', u'192.168.68.13', u'192.168.68.14', u'192.168.68.15', u'192.168.68.16'], [u'192.168.68.117', u'192.168.68.17', u'192.168.68.18', u'192.168.68.19', u'192.168.68.20', u'code.suyatitech.com']])

class uptimeMain:
	def __init__(self):
		
	
                self.uptm = uptimecheck()
	def hostQfetch(self,n,data):
  		print("\n\n",data)
		print(n,data[n])
		for i in xrange(len(data[n])):
			ndata = data[n][i]
			print(ndata)   
      #Thread(target = hostPing(ndata)).start()
 			self.uptm.hostPing(ndata)
	def repeat(self):
		threading.Timer(30, self.repeat).start()
		for i in range(5):
			Thread(target = self.hostQfetch(i,data)).start()

    #sleep(30)
    
def uprepeat():
   threading.Timer(10.0, uprepeat).start()
   Thread(target = ifUp()).start()

if __name__ == '__main__':
	uptm = uptimecheck()
	main = uptimeMain()
	main.repeat()		
    #sleep(30)
    
